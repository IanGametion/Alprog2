﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace IndividualTask_ModifyProject
{
    public partial class frmModify : Form
    {
        public frmModify()
        {
            InitializeComponent();
        }

        // CHRISTIAN 412024013

        String nameFile = "TestScores.txt";
        private bool FileExists(string fileName)
        {
            if (!File.Exists(fileName))
            {
                btnCreate.Enabled = true;
                btnWrite.Enabled = false;
                btnShow.Enabled = false;
                txtScore.Enabled = false;
                return false;
            }
            else
            {
                btnCreate.Enabled = false;
                btnWrite.Enabled = true;
                btnShow.Enabled = true;
                txtScore.Enabled = true;
                return true;
            }
        }

        private int Highest(int[] inpArr)
        {
            int highest = inpArr[0];
            for (int idx = 1; idx < inpArr.Length; idx++)
            {
                if (inpArr[idx] > highest)
                    highest = inpArr[idx];
            }
            return highest;
        }

        private int Lowest(int[] inpArr)
        {
            int lowest = inpArr[0];
            for (int idx = 1; idx < inpArr.Length; idx++)
            {
                if (inpArr[idx] < lowest)
                    lowest = inpArr[idx];
            }
            return lowest;
        }

        private decimal Average(int[] inpArr)
        {
            int total = 0;
            decimal average;
            for (int idx = 1; idx < inpArr.Length; idx++)
            {
                total += inpArr[idx];
            }
            average = Convert.ToDecimal(total) / Convert.ToDecimal(inpArr.Length);
            return average;
        }

        private void clearForm()
        {
            lblAverage.Text = "";
            lblHighest.Text = "";
            lblLowest.Text = "";
            lstScores.Items.Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmModify_Load(object sender, EventArgs e)
        {
            clearForm();
        }

        private int[] getScores(int SIZE)
        {
            try
            {
                //const int SIZE = 5;
                int[] scores = new int[SIZE];
                int idx = 0;
                StreamReader inputFile;

                inputFile = File.OpenText("TestScores.txt");
                while (!inputFile.EndOfStream && idx < scores.Length)
                {
                    scores[idx] = int.Parse(inputFile.ReadLine());
                    idx++;
                }
                inputFile.Close();
                return scores;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return Array.Empty<int>();
            }
        }

        //LIMITKAN KEYBOARD UNTUK HANYA BISA NUMERIK
        private void txtScore_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            try
            {
                StreamWriter outputFile;
                outputFile = File.CreateText(nameFile);
                outputFile.Close(); 
                if (FileExists(nameFile))
                    MessageBox.Show("Create File Success");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnWrite_Click(object sender, EventArgs e)
        {
            //validasi text box tidak diisi
            if (!string.IsNullOrEmpty(txtScore.Text))
            {
                //validasi text box harus diisi dengan numerik (0-100)
                int score = Int32.Parse(txtScore.Text);
                if (score >= 0 && score <= 100)
                {
                    try
                    {
                        StreamWriter outputFile;
                        outputFile = File.AppendText(nameFile);
                        outputFile.WriteLine(txtScore.Text.Trim());
                        outputFile.Close();
                        lstScores.Items.Add(txtScore.Text);
                        MessageBox.Show("The score was written");
                        txtScore.Clear();
                        txtScore.Focus();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
                else
                    MessageBox.Show("Please Fill the score in between 0 - 100");
            }
            else
                MessageBox.Show("Please fill the score");
        }
        
        private void btnShow_Click(object sender, EventArgs e)
        {
            int count = lstScores.Items.Count;
            //const int SIZE = 5;
            int[] scores = new int[count];
            scores = getScores(count);
            //foreach (int value in scores)
            //    lstScores.Items.Add(value);

            lblHighest.Text = Highest(scores).ToString();
            lblLowest.Text = Lowest(scores).ToString();
            lblAverage.Text = Average(scores).ToString();
        }
    }
}
