﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Task_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            lblPredicate.Text = "";
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtIPK.Clear();
            txtStudyPeriod.Clear();
            lblPredicate.Text = "";
            txtIPK.Focus();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCalculatePred_Click(object sender, EventArgs e)
        {
            double ipk = Convert.ToDouble(txtIPK.Text);
            int studyPeriod = Convert.ToInt16(txtStudyPeriod.Text);
            try
            {
                if (ipk < 3.51 || studyPeriod > 5)
                {
                    lblPredicate.Text = "You are not eligable to receive Cum Laude.";
                    if (ipk >= 3.01 && ipk <= 3.51 && studyPeriod <= 5)
                    {
                        MessageBox.Show("But you are eligable to receive Sangat Memuaskan.");
                    }
                    else if (ipk >= 2.76 && ipk <= 3.00 && studyPeriod <= 5)
                    {
                        MessageBox.Show("But you are eligable to receive Memuaskan.");
                    }
                    else if (ipk >= 2.00 && ipk <= 2.75 && studyPeriod <= 5)
                    {
                        MessageBox.Show("But you are eligable to receive Lulus.");
                    }
                    else if (ipk < 2.00 && studyPeriod >= 5)
                    {
                        MessageBox.Show("You didn't Pass. Another Semester For You :)");
                    }
                }
                else if (ipk >= 3.51 && studyPeriod <= 5)
                {
                    lblPredicate.Text = "You are eligable to receive Cum Laude.";
                    if (ipk >= 3.91 && ipk <= 3.96 && studyPeriod <= 5)
                    {
                        MessageBox.Show("And you are eligable to receive Magna Cum Laude.");
                    }
                    else if (ipk >= 3.97 && studyPeriod <= 5)
                    {
                        MessageBox.Show("And you are eligable to receive Summa Cum Laude!!!");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}